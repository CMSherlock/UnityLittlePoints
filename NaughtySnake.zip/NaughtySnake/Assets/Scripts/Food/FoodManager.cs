﻿using System.Collections;
using System.Collections.Generic;
using UnityEngine;

public class FoodManager : MonoBehaviour {

	public FrameManager Border;
	public GameObject FoodPref;
    public SnakeManager snakeManager;                //send this parameter to foodSensor

    private float[] borderInfo = new float[4];		//Inner Rank :: Left Right Top Bottom
	private float zPos = 0;                         //the z position of the frame/player( in case we change the z position of the game )

    [HideInInspector] public GameObject currentFood = null;           //debugging parameter


    void Start () {
		zPos = Border.Frame_Bottom.z;				//we can get any Frame we like

        var offset = 0.2f;
		borderInfo[0] = Border.Frame_Left.x + offset * 1;
		borderInfo[1] = Border.Frame_Right.x + offset * -1;
		borderInfo[2] = Border.Frame_Top.y + offset * -1;
		borderInfo[3] = Border.Frame_Bottom.y + offset * 1;
	}

	void Update () {

        //Use this or use the code in foodSensor
        //Use this to fix problem when there is something wrong with the food
        if (!currentFood)
        {
            //generate next food
            GenerateNextFood();
        }

    }

	public void GenerateNextFood(){

		Vector3 nextPos = GetRandomPosition();
		Quaternion nextRot = GetRandomRotation();
		GameObject food = Instantiate(FoodPref , nextPos , nextRot , transform);
        food.GetComponent<FoodSensor>().SetManagers( snakeManager , transform.GetComponent<FoodManager>() );
		currentFood = food;
	}

	private Vector3 GetRandomPosition(){

		//Get a random x
		float x = Random.Range(borderInfo[0] , borderInfo[1]);
		float y = Random.Range(borderInfo[2] , borderInfo[3]);
		Vector3 pos = new Vector3(x,y,zPos);
		return pos;
	}

	private Quaternion GetRandomRotation(){
		float angle = Random.Range(0f,360f);
		Quaternion rot = new Quaternion(0,0,angle,0);

		return rot;
	}
}
