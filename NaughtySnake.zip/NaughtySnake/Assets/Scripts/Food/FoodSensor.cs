﻿using System.Collections;
using System.Collections.Generic;
using UnityEngine;

public class FoodSensor : MonoBehaviour {

    private SnakeManager snakeManager;
    private FoodManager foodManager;

    private int volume = 1;                             //define how many bodys will we add per time


    public void SetManagers(SnakeManager snake , FoodManager food )
    {
        snakeManager = snake;
        foodManager = food;

    }

    private void OnTriggerEnter2D(Collider2D collision)
    {
        //Only the head can eat the food
        if (collision.CompareTag("SnakeHead"))
        {
            snakeManager.AddNewBody(volume);
            //foodManager.GenerateNextFood();           //use this or the update code in foodmanager
            foodManager.currentFood = null;
            Destroy(gameObject);
        }

    }

}
