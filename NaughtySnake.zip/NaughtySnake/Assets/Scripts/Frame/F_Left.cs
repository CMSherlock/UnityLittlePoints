﻿using System.Collections;
using System.Collections.Generic;
using UnityEngine;

public class F_Left : MonoBehaviour {

    private Vector3 rightPos;
    private float targetDisTimes;
    private float offset = -1;              //保证蛇的身体关节不会被移动过去后又碰到墙壁，造成无限的传送

    // Use this for initialization
    void Start () {
        FrameManager frameManager = transform.parent.GetComponent<FrameManager>();
        offset = frameManager.Offset * offset;
        targetDisTimes = frameManager.TargetDisTimes;
        rightPos = new Vector3(frameManager.Frame_Right.x + offset,frameManager.Frame_Right.y, frameManager.Frame_Right.z);
        //Debug.Log("Left");
    }

    private void OnTriggerEnter2D(Collider2D collision)
    {
        Transform collTrans = collision.transform;
        Vector3 collPos = collTrans.position;
        float angle = collTrans.rotation.eulerAngles.z;

        Vector3 tmpQua = new Vector3(-Mathf.Sin(angle * Mathf.Deg2Rad), Mathf.Cos(angle * Mathf.Deg2Rad), 0);
        tmpQua = tmpQua.normalized * targetDisTimes;
        Vector3 target = collPos + tmpQua;
        Vector3 transmitDestination = new Vector3(rightPos.x, collPos.y, collPos.z);

        if (collision.CompareTag("SnakeHead"))
        {
            collision.transform.GetComponent<_Head>().SetTransmitTarget(transmitDestination, target);
        }
        else if (collision.CompareTag("SnakeBody") || collision.CompareTag("SnakeFirstBody"))
        {
            collision.transform.GetComponent<_Body>().SetTransmitTarget(transmitDestination, target);
        }
    }

}
