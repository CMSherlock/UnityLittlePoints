﻿/**
 * Target : SnakePart->Frame
 * 
 * Description : 用于给所有碰撞到Frame的物体传递穿越信息
 * */



using System.Collections;
using System.Collections.Generic;
using UnityEngine;

public class FrameManager : MonoBehaviour {


    private Vector3 frame_Left;
    private Vector3 frame_Top;
    private Vector3 frame_Right;
    private Vector3 frame_Bottom;
    private float offset;               //Change this when Changes the map;
    private float targetDisTimes;

    public float Offset
    {
        get { return offset; }
    }


    public Vector3 Frame_Bottom
    {
        get { return frame_Bottom; }
    }

    public Vector3 Frame_Right
    {
        get { return frame_Right; }
    }

    public Vector3 Frame_Top
    {
        get { return frame_Top; }
    }

    public Vector3 Frame_Left
    {
        get { return frame_Left; }
    }

    public float TargetDisTimes
    {
        get
        {
            return targetDisTimes;
        }
    }

    /**
     * Awake 确保会在Frame相关函数Start初始化之前初始化
     * 
     * */
    private void Awake()
    {
        offset = 0.25f;
        targetDisTimes = 10f;
        frame_Left = transform.Find("Left").position;
        frame_Top = transform.Find("Top").position;
        frame_Right = transform.Find("Right").position;
        frame_Bottom = transform.Find("Bottom").position;
        //Debug.Log("Manager");
    }
    

}
