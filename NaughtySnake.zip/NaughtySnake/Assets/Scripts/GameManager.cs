﻿using System.Collections;
using System.Collections.Generic;
using UnityEngine.SceneManagement;
using UnityEngine;

public class GameManager : MonoBehaviour {

	



    public void ReStartGame(){
        SceneManager.LoadScene(0);
    }

    public void Exit(){
        Application.Quit();
    }

    public void FreezingTime()
    {
        Time.timeScale = 0;
    }

    public void UnFreezingTime()
    {
        Time.timeScale = 1;
    }

}
