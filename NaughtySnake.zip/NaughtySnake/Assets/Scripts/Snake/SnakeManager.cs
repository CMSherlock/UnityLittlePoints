﻿/**
 * Target : SnakePart->Snake
 * 
 * Description: 脚本用于接收来自BounceBall中的信息。并对蛇的各种操作进行管理
 * 
 * Require Operation: 
 * */

using UnityEngine;
using System.Collections.Generic;

public class SnakeManager : MonoBehaviour
{
    public GameObject BodyPref;
    public Queue<Vector3> TransmitPosQue;
    public GameManager gameManager;
    public UIController UI;

    private Transform _Head;
    private List<Transform> bodyList = new List<Transform>();

    private void Start()
    {
        //找到_Head组件
        _Head = transform.Find("Head").transform;


        TransmitPosQue = new Queue<Vector3>();
    }

    /**
     * 判断传入trans是否为头部
     * */
    public bool IsHead(Transform trans)
    {
        if (_Head == trans)
        {
            return true;
        }
        else
        {
            return false;
        }
    }

    /**
     * Descritpion: Used By _Head.TO GET THE FIRST _Body When _Head Don't have NextBody;
     * */
    public Transform GetFirstBody()
    {
        if (bodyList.Count != 0)
        {
            return bodyList[0];
        }

        return null;
    }

    /**
     * 用于获取上一身体关节
     * */
    public Transform GetLastBody(Transform target)
    {
        int id = -1;
        for (int i = 0; i < bodyList.Count; i++)
        {
            if (target == bodyList[i])
            {
                id = i;
                break;
            }
        }

        if (id == 0)
        {
            return _Head;
        }
        else if (id != -1)
        {
            return bodyList[id - 1];
        }
        else
        {
            Debug.LogError("Do Not Get Match Trans In BodyList!");
            return null;
        }
    }


    public void FreezingTime()
    {
        gameManager.FreezingTime();
    }


    public void UnFreezingTime()
    {
        gameManager.UnFreezingTime();
    }

    public void InvokeDeathUI(){
        UI.InvokeDeathUI();
    }

    /**
     * Server Object : _Head , _Body
     * 
     * Description : 当满足一定条件时，根据传入参数生成新的身体关节
     * */
    public void AddNewBody( int num )
    {
        //pre define the parameters
        Vector3 pos;
        Quaternion rot;
        GameObject go;
        Transform newBody;

        //generate new bodys by the input num
        for(int i = 0; i < num; i++)
        {
            //pos rot 的初始值都为_Head的信息，用以处理list为0的情况
            pos = _Head.position;
            rot = _Head.rotation;
            go = Instantiate(BodyPref, transform);
            newBody = go.transform;

            if (bodyList.Count != 0)                            //此方法可防止当list大小为0时，对BodyList[-1]的不正确访问
            {
                Transform tail = bodyList[bodyList.Count - 1];
                //将新生成的物品，接在最后一个身体关节后面
                pos = tail.position;
                rot = tail.rotation;
                tail.GetComponent<_Body>().NextBody = newBody;
                tail.GetComponent<_Body>().NextBodyScript = newBody.GetComponent<_Body>();
            }
            else
            {
                _Head.GetComponent<_Head>().nextBody = newBody.GetComponent<_Body>();
                newBody.tag = "SnakeFirstBody";
            }


            //对pos加工，使其在前一个body稍微靠后的位置
            float offset = 5f;
            Vector3 movement = _Head.position - _Head.GetComponent<_Head>().LastPosition;
            pos -= movement * offset;

            //角度计算来实现pos加工，但目前失败…………
            // float rotZ = rot.eulerAngles.z;
            // // rotZ += rotZ>0 ? rotZ+90:rotZ-90;
            // // rotZ = rotZ < 0 ? rotZ+270 : rotZ;
            // rotZ += 180;
            // Vector3 vec = new Vector3( -Mathf.Sin(rotZ) , -Mathf.Cos(rotZ) , 0 ).normalized;
            // pos += vec * offset;

            //将位置及角度信息赋值
            newBody.position = pos;
            newBody.rotation = rot;
            bodyList.Add(newBody);
        }

    }
}
