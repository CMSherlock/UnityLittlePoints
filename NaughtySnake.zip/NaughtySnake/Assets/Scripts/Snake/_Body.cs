﻿//绑定在Snake身上的每一个部位

using System.Collections;
using System.Collections.Generic;
using UnityEngine;

public class _Body : MonoBehaviour
{
    private bool isInCorner = false;
    private float delayingTime = 0;
    private int transmitTimes = 0;
    private float transSpeed = 0.12f;
    private float rotateSpeed = 0.1f;
    private SnakeManager snakeManager = null;

    public Vector3 targetPos;                                          //目标位置。用于Body移动
    public Quaternion targetQua;
    [HideInInspector]public Transform NextBody = null;
    [HideInInspector]public _Body NextBodyScript = null;
    

    private void Start()
    {
        snakeManager = transform.parent.GetComponent<SnakeManager>();
    }

    private void Update()
    {
        //Put the bug healing method here
        /**
         * This method will check if there is an issue appear by time
         * Time will increase when the distance with the nextbody larger than 20
         * */
        if (NextBody)
        {
            if (Vector3.Distance(transform.position, NextBody.position) > 20f)
            {
                delayingTime += Time.deltaTime;
            }
            else
            {
                delayingTime = 0;
            }
            if (delayingTime > 1)
            {
                Debug.LogError("Body Borken!    " + NextBodyScript.isInCorner.ToString());
                //if (NextBodyScript.transmitTimes == 0)
                //{
                //    Debug.LogError("Body Borken!    NextBody.transmitTimes = " + NextBodyScript.transmitTimes.ToString());
                //}
                delayingTime = 0;
                //NextBodyScript.transmitTimes = 0;
                //NextBody.position = transform.position;
                //transform.Translate(Vector2.up * 100 * Time.deltaTime);
            }
        }
    }


    private void FixedUpdate()
    {
        if (transmitTimes == 0)
        {
            //正常状态下行动方式
            transform.position = Vector3.Lerp(transform.position, targetPos, transSpeed);
            transform.rotation = Quaternion.Lerp(transform.rotation, targetQua, rotateSpeed);
        }
        else if(transmitTimes == 1)
        {
            //DO this when this body needs to transmit once
            transform.Translate(Vector2.up * 2 * Time.deltaTime);
        }
        else if(transmitTimes == 2)
        {
            //Do this when snake hit the corner OR get through and come back quickly
            Vector2 lastBody = snakeManager.GetLastBody(transform).position;
            float dis = Vector2.Distance(transform.position, lastBody);
            if (dis < 20 && !isInCorner)
            {
                //get through and come back quickly
                transmitTimes = 0;
            }
            else
            {
                //hit the corner
                transform.Translate(Vector2.up * 100 * Time.deltaTime);
            }
        }
        else if(transmitTimes > 2 && isInCorner )
        {
            //if it's in corner , just go straight to transmit!
            transform.Translate(Vector2.up * 100 * Time.deltaTime);
        }
        else if (transmitTimes > 2 && !isInCorner)
        {
            //If not in corner , set transmitTimes to 0;
            transmitTimes = 0;
            //transform.position = Vector3.Lerp(transform.position, targetPos, transSpeed);
            //transform.rotation = Quaternion.Lerp(transform.rotation, targetQua, rotateSpeed);
        }
        else
        {
            //When transmitTimes is negative , set it to 0
            Debug.LogError("transmitTimes Error!    transmitTimes = " + transmitTimes.ToString());
            transmitTimes = 0;
        }

        if (NextBodyScript)
        {
            NextBodyScript.targetPos = transform.position;
            NextBodyScript.targetQua = transform.rotation;
        }
    }

    public void SetLockedDirection(Quaternion rotation)
    {
        transmitTimes++;
        transform.rotation = rotation;
    }


    public void SetTransmitTarget(Vector3 target, Vector3 queuePos)
    {
        transform.position = target;
        transmitTimes--;

        if (NextBodyScript)
        {
            NextBodyScript.SetLockedDirection(transform.rotation);
        }
    }

    public void SetIsInCornerColider(bool yesOrNot)
    {
        if(isInCorner != yesOrNot)
        {
            isInCorner = yesOrNot;
        }
    }
}
