﻿using System.Collections;
using System.Collections.Generic;
using UnityEngine;

public class _Head : MonoBehaviour
{

    public float moveSpeed = 100;
    public float rotateSpeed = 150;

    [HideInInspector]public _Body nextBody = null;
    [HideInInspector]public Vector3 LastPosition = Vector3.zero;

    private SnakeManager snakeManager;

    private void Start()
    {
        //获取_Manager对象
        snakeManager = transform.parent.GetComponent<SnakeManager>();
    }

    private void Update()
    {

        //更新位置信息
        LastPosition = transform.position;

        //Use this to debug
        if (Input.GetKeyDown(KeyCode.Space))
        {
            snakeManager.AddNewBody(1);
            if (!nextBody)
            {
                nextBody = snakeManager.GetFirstBody().GetComponent<_Body>();
            }
        }
    }

    private void FixedUpdate()
    {
        float moveAxis = Input.GetAxis("Horizontal");
        transform.Translate(Vector2.up * moveSpeed * Time.deltaTime);              //向前移动，不受输入影响
        transform.Rotate(new Vector3(0, 0, -moveAxis * rotateSpeed * Time.deltaTime));         //转向
       
        if (nextBody)
        {
            nextBody.targetPos = transform.position;
            nextBody.targetQua = transform.rotation;
        }
    }


    public void SetTransmitTarget(Vector3 target, Vector3 queuePos)
    {
        //将头移动到目标穿越位置
        transform.position = target;

        if (nextBody)
        {
            nextBody.SetLockedDirection(transform.rotation);
        }
    }


    private void OnTriggerEnter2D(Collider2D collision)
    {

       if ( collision.CompareTag("SnakeBody") && collision.transform != nextBody)
       {
           //TODO :: GO Die
            snakeManager.FreezingTime();
            snakeManager.InvokeDeathUI();
       }

    }
}
