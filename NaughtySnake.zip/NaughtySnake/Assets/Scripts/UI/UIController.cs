﻿using System.Collections;
using System.Collections.Generic;
using UnityEngine;

public class UIController : MonoBehaviour {

	public GameManager gameManager;
	public GameObject DeathPanel;
	public GameObject StartPanel;

	private void Awake(){
		gameManager.FreezingTime();
	}


	public void InvokeDeathUI(){

		DeathPanel.SetActive(true);

	}

	public void OnStartButton(){

		gameManager.UnFreezingTime();
		StartPanel.SetActive(false);
	}


	public void OnRestartButton(){

		gameManager.ReStartGame();
		gameManager.UnFreezingTime();
		DeathPanel.SetActive(false);
	}


	public void OnExitButton(){
		gameManager.Exit();
	}


}
